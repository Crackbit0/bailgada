**This collection includes templates that have been modified from their original versions, some of which have undergone extensive editing with newly discovered paths and bypasses.** 
*original authors deserve respect for their contributions.

**How to Use**:
Save the templates to a designated folder (e.g., "private-templates").

Execute the following command in your terminal:
```
nuclei -l listofdomains.txt -t ~/path/to/private-templates | tee -a nucleid_with_private_templates.txt
```

**Please remember that these templates are intended for my personal use. 
However, I have decided to share them for your benefit as well. I do not expect any credit or mentions in return**

**Act Responsibly.Avoid using these templates
on unauthorized targets**


